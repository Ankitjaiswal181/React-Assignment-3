import logo from './logo.svg';
import './App.css';
import FormValidation from './Component/FormValidation';

function App() {
  return (
    <div className="App">
     <FormValidation/>
    </div>
  );
}

export default App;
